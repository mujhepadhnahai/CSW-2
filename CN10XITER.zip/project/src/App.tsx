import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ChevronDown, Terminal, Code2, Braces, Laptop, Cpu, Wifi, Rocket, Heart, Star, Zap } from 'lucide-react';

function App() {
  const [showMore, setShowMore] = useState(false);

  const floatingIcons = [
    { icon: <Laptop className="w-6 h-6" />, color: "text-blue-400" },
    { icon: <Cpu className="w-6 h-6" />, color: "text-green-400" },
    { icon: <Wifi className="w-6 h-6" />, color: "text-purple-400" }
  ];

  const excitementReasons = [
    { icon: <Rocket className="w-6 h-6" />, text: "Revolutionary Tech Stack" },
    { icon: <Heart className="w-6 h-6" />, text: "Amazing Community" },
    { icon: <Star className="w-6 h-6" />, text: "Game-Changing Features" },
    { icon: <Zap className="w-6 h-6" />, text: "Lightning Fast Performance" }
  ];

  return (
    <div className="min-h-screen bg-[#0A1120] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Floating background elements */}
      {floatingIcons.map((item, index) => (
        <motion.div
          key={index}
          className={`absolute ${item.color}`}
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0.2
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: [0.2, 0.5, 0.2],
            scale: [1, 1.2, 1]
          }}
          transition={{
            duration: 10 + Math.random() * 10,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        >
          {item.icon}
        </motion.div>
      ))}

      <div className="max-w-3xl w-full relative">
        {/* Glowing effect behind the card */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 blur-3xl"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />

        <AnimatePresence mode="wait">
          {!showMore ? (
            <motion.div
              key="main"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-[#1A2332]/80 backdrop-blur-lg rounded-2xl overflow-hidden border border-[#2A3343] shadow-xl relative"
            >
              <div className="flex items-center gap-2 px-4 py-2 bg-[#0D1524] border-b border-[#2A3343]">
                <div className="flex gap-1.5">
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#FF5F56] cursor-pointer"
                  />
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#FFBD2E] cursor-pointer"
                  />
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#27C93F] cursor-pointer"
                  />
                </div>
                <div className="flex-1 text-center">
                  <motion.span 
                    className="text-sm text-gray-400 font-mono"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    excitement.tsx
                  </motion.span>
                </div>
              </div>
              
              <div className="p-8">
                <motion.div
                  className="flex items-center justify-center gap-4 mb-8"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 10 }}
                >
                  <motion.div
                    whileHover={{ rotate: 180, scale: 1.2 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Terminal className="w-10 h-10 text-emerald-400" />
                  </motion.div>
                  <motion.div
                    whileHover={{ rotate: -180, scale: 1.2 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Code2 className="w-10 h-10 text-blue-400" />
                  </motion.div>
                  <motion.div
                    whileHover={{ rotate: 180, scale: 1.2 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Braces className="w-10 h-10 text-purple-400" />
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="mb-8 relative"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="absolute -left-4 top-0 bottom-0 border-l-2 border-[#2A3343] pl-3">
                    <motion.div 
                      className="text-gray-500 font-mono text-sm"
                      animate={{ opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >1</motion.div>
                    <motion.div 
                      className="text-gray-500 font-mono text-sm"
                      animate={{ opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 2, delay: 0.3, repeat: Infinity }}
                    >2</motion.div>
                    <motion.div 
                      className="text-gray-500 font-mono text-sm"
                      animate={{ opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 2, delay: 0.6, repeat: Infinity }}
                    >3</motion.div>
                  </div>
                  <div className="pl-6">
                    <motion.span 
                      className="text-pink-400"
                      whileHover={{ scale: 1.1 }}
                    >const</motion.span>{" "}
                    <motion.span 
                      className="text-blue-400"
                      whileHover={{ scale: 1.1 }}
                    >excitement</motion.span>{" "}
                    <span className="text-pink-400">=</span>{" "}
                    <span className="text-emerald-300">{"{"}</span>
                    <div className="pl-4">
                      <motion.span 
                        className="text-purple-400"
                        whileHover={{ scale: 1.1 }}
                      >level:</motion.span>{" "}
                      <motion.span 
                        className="text-orange-300"
                        whileHover={{ scale: 1.1 }}
                      >'Maximum'</motion.span>,
                    </div>
                    <span className="text-emerald-300">{"}"}</span>
                  </div>
                </motion.div>

                <motion.h1 
                  className="text-4xl md:text-5xl font-bold text-center mb-6 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  I'm So Excited! 🚀
                </motion.h1>
                
                <motion.p 
                  className="text-xl md:text-2xl text-center text-gray-300 mb-8 font-mono"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                >
                  {"<"}something incredible{"/>"}
                </motion.p>

                {/* New Excitement Section */}
                <motion.div
                  className="grid grid-cols-2 gap-4 mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  {excitementReasons.map((reason, index) => (
                    <motion.div
                      key={index}
                      className="bg-[#2A3343]/50 p-4 rounded-lg border border-[#3A4353] flex items-center gap-3"
                      whileHover={{ scale: 1.05, backgroundColor: "rgba(58, 67, 83, 0.7)" }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.8 + index * 0.1 }}
                    >
                      <motion.div
                        className="text-emerald-400"
                        animate={{ rotate: [0, 360] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        {reason.icon}
                      </motion.div>
                      <span className="text-gray-300 font-mono text-sm">{reason.text}</span>
                    </motion.div>
                  ))}
                </motion.div>

                <motion.div 
                  className="flex justify-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  <motion.button
                    onClick={() => setShowMore(true)}
                    className="group relative px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg font-mono font-semibold transition-all duration-300 flex items-center gap-2 hover:from-blue-600 hover:to-purple-600 hover:shadow-lg hover:shadow-purple-500/20"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    npm run reveal
                    <motion.div
                      animate={{ y: [0, 5, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      <ChevronDown className="w-5 h-5" />
                    </motion.div>
                  </motion.button>
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="more"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-[#1A2332]/80 backdrop-blur-lg rounded-2xl overflow-hidden border border-[#2A3343] shadow-xl"
            >
              <div className="flex items-center gap-2 px-4 py-2 bg-[#0D1524] border-b border-[#2A3343]">
                <div className="flex gap-1.5">
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#FF5F56] cursor-pointer"
                  />
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#FFBD2E] cursor-pointer"
                  />
                  <motion.div 
                    whileHover={{ scale: 1.2 }}
                    className="w-3 h-3 rounded-full bg-[#27C93F] cursor-pointer"
                  />
                </div>
                <div className="flex-1 text-center">
                  <motion.span 
                    className="text-sm text-gray-400 font-mono"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    compiling.tsx
                  </motion.span>
                </div>
              </div>

              <div className="p-8">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{
                    type: "spring",
                    stiffness: 200,
                    damping: 15
                  }}
                  className="relative"
                >
                  <motion.div
                    animate={{ 
                      rotate: 360,
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      rotate: { duration: 2, repeat: Infinity, ease: "linear" },
                      scale: { duration: 1, repeat: Infinity }
                    }}
                    className="absolute -top-12 left-1/2 -translate-x-1/2"
                  >
                    <Sparkles className="w-16 h-16 text-yellow-300" />
                  </motion.div>
                  
                  <div className="mt-12 mb-6 font-mono">
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                      className="flex items-center gap-2 text-emerald-400"
                    >
                      <Terminal className="w-5 h-5" />
                      <span>~/amazing-project $</span>
                    </motion.div>
                    
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: "100%" }}
                      transition={{ delay: 0.5, duration: 1 }}
                      className="h-6 bg-gradient-to-r from-blue-500/20 to-purple-500/20 mt-2 rounded overflow-hidden"
                    >
                      <motion.div
                        initial={{ width: "0%" }}
                        animate={{ width: "60%" }}
                        transition={{ delay: 1.5, duration: 2 }}
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500 relative"
                      >
                        <motion.div
                          className="absolute top-0 right-0 bottom-0 w-20 bg-gradient-to-r from-transparent to-white/20"
                          animate={{ x: [0, 100, 0] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        />
                      </motion.div>
                    </motion.div>
                  </div>

                  <motion.h2
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="text-3xl md:text-4xl font-bold text-center mb-4 font-mono text-gray-200"
                  >
                    {"<"}Compiling Something Amazing{"/>"}
                  </motion.h2>
                  
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="text-xl text-center text-emerald-400 font-mono mb-4"
                  >
                    Stay tuned! with CN 10X ITER 🚀
                  </motion.p>

                  <motion.p
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.7 }}
                    className="text-lg text-center text-purple-300 italic"
                  >
                    "Is it a tech event or something?? 
                    <br />
                    <span className="text-sm text-gray-400">
                      -- Every non-developer friend ever 😅
                    </span>
                  </motion.p>

                  <motion.button
                    onClick={() => setShowMore(false)}
                    className="mt-8 px-6 py-2 bg-[#2A3343] hover:bg-[#3A4353] rounded-lg font-mono mx-auto block transition-all duration-300 text-gray-300"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    cd ..
                  </motion.button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;